"""PyReqVer - Python 依赖版本检查工具

PyReqVer 是一个命令行工具，帮助您找到支持您 requirements.txt 文件中所有库的 Python 版本。
"""

__version__ = "0.1.0"